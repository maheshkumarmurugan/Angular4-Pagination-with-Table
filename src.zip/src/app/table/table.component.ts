import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  title = 'JSON to Table Example';
  constructor (private httpService: HttpClient){}
  details: string [];

  ngOnInit() {    
    for (let i = 1; i <= 11; i++) {
      this.httpService.get('./assets/sample_data.json').subscribe(
        data => {
          this.details = data as string [];
        })    
      }
       
  }
   
}
